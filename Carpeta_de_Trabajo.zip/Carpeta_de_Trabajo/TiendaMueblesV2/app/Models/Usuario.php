<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class Usuario extends Authenticatable
{
    use HasFactory, Notifiable;

    protected $table = 'usuarios';

    protected $fillable = [
        'nombre',
        'apellidos',
        'email',
        'password',
        'rol_id',
        'intentos_fallidos',
        'bloqueado_hasta'
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected $casts = [
        'bloqueado_hasta' => 'datetime',
        'password' => 'hashed',
    ];

    public function rol()
    {
        return $this->belongsTo(Rol::class);
    }
    public static function verificarCredenciales($email, $password)
    {
        $usuario = self::where('email', $email)->first();

        if (! $usuario) {
            return false;
        }

        // Si está bloqueado
        if ($usuario->bloqueado_hasta && now()->lessThan($usuario->bloqueado_hasta)) {
            return 'bloqueado';
        }

        // Validación de password
        if (! \Hash::check($password, $usuario->password)) {

            // Incrementar intentos fallidos
            $usuario->intentos_fallidos += 1;

            if ($usuario->intentos_fallidos >= 3) {
                $usuario->bloqueado_hasta = now()->addMinutes(5); // ejemplo
            }

            $usuario->save();
            return false;
        }

        // Si credenciales correctas, reseteamos
        $usuario->intentos_fallidos = 0;
        $usuario->bloqueado_hasta = null;
        $usuario->save();

        return $usuario;
    }
}
