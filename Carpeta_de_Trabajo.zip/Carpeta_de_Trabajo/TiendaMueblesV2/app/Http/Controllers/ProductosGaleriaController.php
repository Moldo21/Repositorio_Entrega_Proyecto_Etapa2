<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cookie;

class ProductosGaleriaController extends Controller
{
    /**
     * Subir imágenes a un mueble.
     */
    public function store(Request $request, $mueble)
    {
        $request->validate([
            'imagenes.*' => 'required|image|mimes:jpg,jpeg,png|max:2048'
        ]);

        // Obtener muebles de la cookie
        $muebles = json_decode(Cookie::get('mueblesDB', '[]'), true) ?? [];

        // Buscar mueble por id
        foreach ($muebles as &$prod) {
            if ($prod['id'] == $mueble) {
                foreach ($request->file('imagenes') as $archivo) {
                    $nombreImagen = 'mueble_' . time() . '_' . rand(1000, 9999) . '.' . $archivo->getClientOriginalExtension();
                    $archivo->move(public_path('imagenes'), $nombreImagen);

                    if (!isset($prod['imagenes']) || !is_array($prod['imagenes'])) {
                        $prod['imagenes'] = [];
                    }
                    $prod['imagenes'][] = $nombreImagen;
                }
                break;
            }
        }

        // Guardar de nuevo en la cookie
        Cookie::queue('mueblesDB', json_encode($muebles), 60 * 24 * 30);

        return back()->with('success', 'Imágenes subidas correctamente.');
    }

    /**
     * Eliminar una imagen de un mueble.
     */
    public function destroy(Request $request, $mueble, $imagen)
    {
        $muebles = json_decode(Cookie::get('mueblesDB', '[]'), true) ?? [];

        foreach ($muebles as &$prod) {
            if ($prod['id'] == $mueble && isset($prod['imagenes']) && is_array($prod['imagenes'])) {
                $prod['imagenes'] = array_filter($prod['imagenes'], function ($img) use ($imagen) {
                    return $img !== $imagen;
                });
                $prod['imagenes'] = array_values($prod['imagenes']); // reindexar
                break;
            }
        }

        // Guardar cookie
        Cookie::queue('mueblesDB', json_encode($muebles), 60 * 24 * 30);

        // Borrar archivo físico si existe
        $ruta = public_path('imagenes/' . $imagen);
        if (file_exists($ruta)) {
            @unlink($ruta);
        }

        return back()->with('success', 'Imagen eliminada correctamente.');
    }

    /**
     * Establecer una imagen como principal.
     */
    public function setMain(Request $request, $mueble, $imagen)
    {
        $muebles = json_decode(Cookie::get('mueblesDB', '[]'), true) ?? [];

        foreach ($muebles as &$prod) {
            if ($prod['id'] == $mueble && isset($prod['imagenes']) && is_array($prod['imagenes'])) {
                // Colocar la imagen seleccionada al inicio del array
                $prod['imagenes'] = array_values(array_filter($prod['imagenes'], function ($img) use ($imagen) {
                    return $img !== $imagen;
                }));
                array_unshift($prod['imagenes'], $imagen);
                break;
            }
        }

        Cookie::queue('mueblesDB', json_encode($muebles), 60 * 24 * 30);

        return back()->with('success', 'Imagen principal actualizada correctamente.');
    }
}
