<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cookie;
use App\Models\Categoria;

class ProductosController extends Controller
{
    public function create(Request $request)
    {
        $sesionId = $request->query('sesionId');
        $usuario = session()->get('usuarios')[$sesionId] ?? null;
        $usuario = $usuario ? json_decode($usuario) : null;

        if (!$usuario || $usuario->rol !== 'admin') {
            return redirect()->route('muebles.index')->with('error', 'No tienes permiso.');
        }

        $categoriasCookie = Cookie::get('categorias');
        if ($categoriasCookie) {
            $categoriasArray = json_decode($categoriasCookie, true);
            $categorias = array_map(fn($c) => new Categoria($c['id'], $c['nombre'], $c['descripcion']), $categoriasArray);
        } else {
            $categorias = Categoria::datosCategorias();
        }

        return view('productos.create', [
            'sesionId' => $sesionId,
            'usuario' => $usuario,
            'categorias' => $categorias
        ]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'categoria_id' => 'required|integer',
            'nombre' => 'required|string|max:80',
            'descripcion' => 'required|string|max:255',
            'precio' => 'required|numeric|min:0',
            'stock' => 'required|integer|min:0',
            'materiales' => 'required|string|max:255',
            'dimensiones' => 'required|string|max:255',
            'color_principal' => 'required|string|max:50',
            'destacado' => 'nullable|boolean',
            'imagen' => 'required|image|mimes:jpg,jpeg,png'
        ]);

        // Leer muebles existentes de cookie
        $mueblesCookie = Cookie::get('mueblesDB');
        $muebles = $mueblesCookie ? json_decode($mueblesCookie, true) : [];

        // Calcular nuevo ID
        $nuevoId = !empty($muebles) ? max(array_column($muebles, 'id')) + 1 : 100;

        // Guardar imagen
        $archivo = $request->file('imagen');
        $nombreImagen = 'mueble_' . time() . '.' . $archivo->getClientOriginalExtension();
        $archivo->move(public_path('imagenes'), $nombreImagen);

        // Crear nuevo mueble
        $nuevoMueble = [
            'id' => $nuevoId,
            'categoria_id' => (int)$request->categoria_id,
            'nombre' => $request->nombre,
            'descripcion' => $request->descripcion,
            'precio' => (float)$request->precio,
            'stock' => (int)$request->stock,
            'materiales' => $request->materiales,
            'dimensiones' => $request->dimensiones,
            'color_principal' => $request->color_principal,
            'destacado' => $request->has('destacado'),
            'imagenes' => [$nombreImagen]
        ];

        // Insertar en array y guardar en cookie 30 días
        $muebles[] = $nuevoMueble;
        Cookie::queue('mueblesDB', json_encode($muebles), 60 * 24 * 30);

        return redirect()->route('muebles.index', ['sesionId' => $request->sesionId])
            ->with('success', 'Mueble creado correctamente.');
    }

    public function edit(Request $request, $id)
    {
        $sesionId = $request->query('sesionId');
        $usuario = session()->get('usuarios')[$sesionId] ?? null;
        $usuario = $usuario ? json_decode($usuario) : null;

        if (!$usuario || $usuario->rol !== 'admin') {
            return redirect()->route('muebles.index')->with('error', 'No tienes permiso.');
        }

        $muebles = json_decode(Cookie::get('mueblesDB'), true) ?? [];
        $producto = collect($muebles)->firstWhere('id', $id);

        if (!$producto) {
            return redirect()->route('muebles.index')->with('error', 'El mueble no existe.');
        }

        // Obtener categorías desde cookie
        $categoriasCookie = Cookie::get('categorias');
        if ($categoriasCookie) {
            $categoriasArray = json_decode($categoriasCookie, true);
            $categorias = array_map(
                fn($c) =>
                new Categoria($c['id'], $c['nombre'], $c['descripcion']),
                $categoriasArray
            );
        } else {
            $categorias = Categoria::datosCategorias();
        }

        return view('productos.edit', [
            'producto' => (object)$producto,
            'categorias' => $categorias,
            'sesionId' => $sesionId
        ]);
    }

    /* ----------------------------------------------
        ACTUALIZAR
    ---------------------------------------------- */
    public function update(Request $request, $id)
    {
        $request->validate([
            'categoria_id' => 'required|integer',
            'nombre' => 'required|string|max:80',
            'descripcion' => 'required|string|max:255',
            'precio' => 'required|numeric|min:0',
            'stock' => 'required|integer|min:0',
            'materiales' => 'required|string|max:255',
            'dimensiones' => 'required|string|max:255',
            'color_principal' => 'required|string|max:50',
            'destacado' => 'required|boolean',
        ]);

        $muebles = json_decode(Cookie::get('mueblesDB'), true) ?? [];
        $index = array_search($id, array_column($muebles, 'id'));

        if ($index === false) {
            return redirect()->back()->with('error', 'Producto no encontrado.');
        }

        // Actualizar campos
        $muebles[$index]['categoria_id'] = (int)$request->categoria_id;
        $muebles[$index]['nombre'] = $request->nombre;
        $muebles[$index]['descripcion'] = $request->descripcion;
        $muebles[$index]['precio'] = (float)$request->precio;
        $muebles[$index]['stock'] = (int)$request->stock;
        $muebles[$index]['materiales'] = $request->materiales;
        $muebles[$index]['dimensiones'] = $request->dimensiones;
        $muebles[$index]['color_principal'] = $request->color_principal;
        $muebles[$index]['destacado'] = $request->has('destacado');

        Cookie::queue('mueblesDB', json_encode($muebles), 60 * 24 * 30);

        return redirect()->route('muebles.index', ['sesionId' => $request->query('sesionId')])
            ->with('success', 'Producto actualizado correctamente.');
    }

    /* ----------------------------------------------
        ELIMINAR
    ---------------------------------------------- */
    public function destroy(Request $request, $id)
    {
        $muebles = json_decode(Cookie::get('mueblesDB'), true) ?? [];

        $filtrado = array_filter($muebles, fn($m) => $m['id'] != $id);

        Cookie::queue('mueblesDB', json_encode(array_values($filtrado)), 60 * 24 * 30);

        return redirect()->route('muebles.index', ['sesionId' => $request->query('sesionId')])
            ->with('success', 'Producto eliminado correctamente.');
    }


    /* ----------------------------------------------
        GALERÍA: añadir imágenes
    ---------------------------------------------- */
    public function storeGaleria(Request $request, $id)
    {
        $request->validate([
            'imagenes.*' => 'required|image|mimes:jpg,jpeg,png'
        ]);

        $muebles = json_decode(Cookie::get('mueblesDB'), true) ?? [];
        $index = array_search($id, array_column($muebles, 'id'));

        if ($index === false) {
            return back()->with('error', 'Producto no encontrado.');
        }

        foreach ($request->file('imagenes') as $img) {
            $nombre = 'galeria_' . time() . '_' . rand(1000, 9999) . '.' . $img->getClientOriginalExtension();
            $img->move(public_path('imagenes'), $nombre);

            $muebles[$index]['imagenes'][] = $nombre;
        }

        Cookie::queue('mueblesDB', json_encode($muebles), 60 * 24 * 30);

        return back()->with('success', 'Imágenes añadidas.');
    }


    /* ----------------------------------------------
        GALERÍA: marcar como principal
    ---------------------------------------------- */
    public function setPrincipal(Request $request, $id, $imagen)
    {
        $muebles = json_decode(Cookie::get('mueblesDB'), true) ?? [];
        $index = array_search($id, array_column($muebles, 'id'));

        if ($index === false) {
            return back()->with('error', 'Producto no encontrado.');
        }

        $imagenes = $muebles[$index]['imagenes'];

        if (!in_array($imagen, $imagenes)) {
            return back()->with('error', 'La imagen no existe.');
        }

        // Poner la imagen seleccionada como primera
        $imagenes = array_values(array_diff($imagenes, [$imagen]));
        array_unshift($imagenes, $imagen);

        $muebles[$index]['imagenes'] = $imagenes;

        Cookie::queue('mueblesDB', json_encode($muebles), 60 * 24 * 30);

        return back()->with('success', 'Imagen principal actualizada.');
    }


    /* ----------------------------------------------
        GALERÍA: eliminar imagen
    ---------------------------------------------- */
    public function destroyImagen(Request $request, $id, $img)
    {
        $muebles = json_decode(Cookie::get('mueblesDB'), true) ?? [];
        $index = array_search($id, array_column($muebles, 'id'));

        if ($index === false) {
            return back()->with('error', 'Producto no encontrado.');
        }

        // No permitir eliminar la última imagen
        if (count($muebles[$index]['imagenes']) <= 1) {
            return back()->with('error', 'El mueble debe tener al menos una imagen.');
        }

        $muebles[$index]['imagenes'] = array_values(
            array_filter($muebles[$index]['imagenes'], fn($i) => $i !== $img)
        );

        Cookie::queue('mueblesDB', json_encode($muebles), 60 * 24 * 30);

        return back()->with('success', 'Imagen eliminada correctamente.');
    }
}
