<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

// Parte no implementada aún

class AdministracionController extends Controller
{

}
