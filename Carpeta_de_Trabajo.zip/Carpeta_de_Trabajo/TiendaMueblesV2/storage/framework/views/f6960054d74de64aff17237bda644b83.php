<?php $__env->startSection('contenido'); ?>
<style>
    .hero {
        background: #000;
        color: #fff;
        padding: 5rem 0;
        text-align: center;
        margin: 0 0 3rem 0;
    }
    .hero h1 { font-size: 3rem; font-weight: 700; margin-bottom: 1rem; }
    .hero p { font-size: 1.2rem; margin-bottom: 2rem; opacity: 0.95; }
    .hero .btn {
        padding: 0.8rem 2.5rem;
        font-weight: 600;
        border-radius: 25px;
        font-size: 1rem;
        transition: all 0.3s ease;
    }
    .btn-light-outline {
        background: transparent;
        color: #fff;
        border: 2px solid #fff;
    }
    .btn-light-outline:hover {
        background: #fff;
        color: #000;
        transform: translateY(-2px);
    }
    .btn-light:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(255,255,255,0.3);
    }
    .section-title { font-size: 2rem; font-weight: 700; margin: 3rem 0 2rem; text-align: center; border-bottom: 2px solid #000; padding-bottom: 1rem; }
    .btn-action { font-weight: 600; border-radius: 8px; padding: 0.6rem 1rem; font-size: 0.9rem; }
    .btn-dark-fill { background: #000; color: #fff; }
    .btn-dark-fill:hover { background: #333; color: #fff; }
    .btn-outline { background: #fff; color: #000; border: 2px solid #000; }
    .btn-outline:hover { background: #000; color: #fff; }
    .badge-featured { background: #000; color: #fff; position: absolute; top: 10px; right: 10px; border-radius: 20px; padding: 0.4rem 0.8rem; font-size: 0.75rem; }
    .img-product { width: 100%; height: 200px; object-fit: cover; }
    .price { font-size: 1.3rem; font-weight: 700; }
    @media (max-width: 768px) {
        .hero h1 { font-size: 2rem; }
        .hero p { font-size: 1rem; }
        .hero { padding: 3rem 0; }
    }
</style>

<!-- Hero Section -->
<section class="hero">
        <div class="container">
            <h1>Bienvenido a Kctta</h1>
            <p>Descubre nuestra colección de muebles de alta calidad</p>
            <a href="#categorias" class="btn btn-light me-2">Explorar Categorías</a>
            <a href="#destacados" class="btn btn-light-outline">Ver Destacados</a>
        </div>
    </section>

    <!-- Categories Section -->
    <section id="categorias" class="py-5">
        <div class="container">
            <h2 class="section-title">Explora Nuestras Categorías</h2>
            <?php if($categorias->count() > 0): ?>
                <p class="text-center text-muted mb-4">
                    Estas son algunas de nuestras categorías, pero si deseas ver más pulsa el botón de ver más categorías.
                </p>
                <div class="row g-4 mb-4">
                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6">
                            <div class="card p-4 text-center h-100">
                                <h5 class="mb-2"><?php echo e($categoria->nombre); ?></h5>
                                <p class="text-muted"><?php echo e($categoria->descripcion); ?></p>
                                <a href="<?php echo e(route('categorias.show', $categoria->id)); ?>" class="btn btn-action btn-dark-fill mt-auto">Ver productos</a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="text-center">
                    <a href="<?php echo e(route('categorias.index')); ?>" class="btn btn-action btn-outline">Ver más categorías →</a>
                </div>
            <?php else: ?>
                <div class="card p-4 text-center">
                    <p class="text-muted">No hay categorías disponibles en este momento.</p>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- Featured Products Section -->
    <section id="destacados" class="py-5">
        <div class="container">
            <h2 class="section-title">Productos Destacados</h2>
            <?php if($productos->count() > 0): ?>
                <div class="row g-4">
                    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 col-lg-4">
                            <div class="card position-relative h-100">
                                <?php if($producto->destacado): ?>
                                    <span class="badge-featured">⭐ Destacado</span>
                                <?php endif; ?>
                                <?php if($producto->imagen_principal): ?>
                                    <img src="<?php echo e(asset('imagenes/' . $producto->imagen_principal)); ?>" alt="<?php echo e($producto->nombre); ?>" class="img-product">
                                <?php else: ?>
                                    <div class="img-product bg-light d-flex align-items-center justify-content-center text-muted">Sin imagen</div>
                                <?php endif; ?>
                                <div class="card-body d-flex flex-column">
                                    <h5 class="card-title"><?php echo e($producto->nombre); ?></h5>
                                    <p class="card-text text-muted flex-grow-1"><?php echo e(Str::limit($producto->descripcion, 80)); ?></p>
                                    <div class="price mb-3">$<?php echo e(number_format($producto->precio, 2)); ?></div>
                                    <div class="d-grid gap-2">
                                        <a href="<?php echo e(route('productos.show', $producto->id)); ?>" class="btn btn-action btn-dark-fill">Ver Detalle</a>
                                        <a href="<?php echo e(route('login')); ?>" class="btn btn-action btn-outline">Comprar</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php else: ?>
                <div class="card p-4 text-center">
                    <p class="text-muted">No hay productos destacados en este momento. ¡Visita nuestras categorías!</p>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- Footer -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('cabecera', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\moldo\Documents\Carpeta_de_Trabajo\TiendaMueblesV2\resources\views/principal.blade.php ENDPATH**/ ?>