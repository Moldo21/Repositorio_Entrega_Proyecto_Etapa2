<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tienda de Muebles</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #fff; color: #000; }
        .navbar {
            background: #000 !important;
            padding: 1.5rem 0 !important;
        }
        .navbar-brand { color: #fff !important; font-weight: 700; font-size: 1.5rem; }
        .nav-link { color: rgba(255,255,255,0.8) !important; }
        .nav-link:hover { color: #fff !important; }
        .card { border: 2px solid #000; border-radius: 10px; }
        .card:hover { transform: translateY(-5px); box-shadow: 0 8px 20px rgba(0,0,0,0.15); }
        footer { background: #000; color: #fff; padding: 2rem 0; margin-top: 3rem; text-align: center; }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg">
        <div class="container">
            <a href="<?php echo e(route('principal')); ?>" class="navbar-brand">Kctta</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('principal')); ?>">Inicio</a></li>
                    <?php if(auth()->check()): ?>
                        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('categorias.index')); ?>">Categorías</a></li>
                        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('carrito.show')); ?>">Carrito</a></li>
                        <?php if(auth()->user()->rol_id === 1): ?>
                            <li class="nav-item"><a class="nav-link" href="<?php echo e(route('productos.create')); ?>">Crear Producto</a></li>
                            <li class="nav-item"><a class="nav-link" href="<?php echo e(route('categorias.create')); ?>">Crear Categoría</a></li>
                        <?php endif; ?>
                        <li class="nav-item"><span class="nav-link text-white">Bienvenido, <?php echo e(auth()->user()->nombre); ?></span></li>
                        <li class="nav-item">
                            <form action="<?php echo e(route('login.logout')); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-outline-light btn-sm">Cerrar sesión</button>
                            </form>
                        </li>
                    <?php else: ?>
                        <li class="nav-item"><a href="<?php echo e(route('login')); ?>" class="btn btn-light btn-sm ms-2">Iniciar sesión</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <?php echo $__env->yieldContent('contenido'); ?>
    </div>

    <footer>
        <div class="container">
            <p>&copy; 2025 Kctta - Tienda de Muebles</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
<?php /**PATH C:\Users\moldo\Documents\Carpeta_de_Trabajo\TiendaMueblesV2\resources\views/cabecera.blade.php ENDPATH**/ ?>