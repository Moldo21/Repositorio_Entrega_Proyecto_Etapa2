<?php $__env->startSection('contenido'); ?>
<div class="container mt-4">
        <h2 class="text-center mb-4">Elige una categoría</h2>

        <?php if($categorias->isEmpty()): ?>
            <div class="text-center mt-4">
                <p>No hay categorías disponibles.</p>
            </div>
        <?php else: ?>
            <div class="row justify-content-center">
                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 col-sm-6 mb-4">
                        <div class="card h-100 shadow-sm">
                            <div class="card-body text-center">
                                <h5 class="card-title"><?php echo e($categoria->nombre); ?></h5>
                                <p class="card-text text-muted"><?php echo e($categoria->descripcion); ?></p>

                                <a href="<?php echo e(route('categorias.show', $categoria->id)); ?>"
                                    class="btn btn-dark w-100 mb-2"
                                    title="Ver productos de <?php echo e($categoria->nombre); ?>">
                                    Ver productos
                                </a>

                                <?php if(auth()->check() && auth()->user()->rol_id === 1): ?>
                                    <a href="<?php echo e(route('categorias.edit', $categoria->id)); ?>"
                                        class="btn btn-warning w-100 mb-2"
                                        title="Editar categoría <?php echo e($categoria->nombre); ?>">
                                        Editar
                                    </a>

                                    <form action="<?php echo e(route('categorias.destroy', $categoria->id)); ?>"
                                        method="POST" onsubmit="return confirm('¿Seguro que deseas eliminar esta categoría?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger w-100">
                                            Eliminar
                                        </button>
                                    </form>
                                <?php endif; ?>

                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <hr>
        <div class="text-center mt-3">
            <a href="<?php echo e(route('principal')); ?>" class="btn btn-dark me-2">
                ← Volver al inicio
            </a>
            <a href="<?php echo e(route('productos.index')); ?>" class="btn btn-secondary">
                Ver todos los productos
            </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('cabecera', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\moldo\Documents\Carpeta_de_Trabajo\TiendaMueblesV2\resources\views/categorias/index.blade.php ENDPATH**/ ?>