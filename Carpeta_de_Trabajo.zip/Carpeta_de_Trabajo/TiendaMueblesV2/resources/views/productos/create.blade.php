@extends('cabecera')

@section('contenido')
    <h2 class="mb-4">Crear nuevo mueble</h2>

    @if ($errors->any())
        <div class="alert alert-danger">
            <strong>Errores:</strong><br>
            @foreach ($errors->all() as $error)
                {{ $error }}<br>
            @endforeach
        </div>
    @endif

    <form method="POST" action="{{ route('productos.store') }}" enctype="multipart/form-data">
        @csrf

        <input type="hidden" name="sesionId" value="{{ $sesionId }}">

        <div class="mb-3">
            <label class="form-label">Categoría</label>
            <select name="categoria_id" class="form-select">
                @foreach ($categorias as $c)
                    <option value="{{ $c->getId() }}">{{ $c->getNombre() }}</option>
                @endforeach
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Nombre</label>
            <input type="text" name="nombre" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Descripción</label>
            <textarea name="descripcion" class="form-control" required></textarea>
        </div>

        <div class="row">
            <div class="col-md-4 mb-3">
                <label class="form-label">Precio (€)</label>
                <input type="number" name="precio" step="0.01" class="form-control" required>
            </div>
            <div class="col-md-4 mb-3">
                <label class="form-label">Stock</label>
                <input type="number" name="stock" class="form-control" required>
            </div>
            <div class="col-md-4 mb-3">
                <label class="form-label">Color principal</label>
                <input type="text" name="color_principal" class="form-control" required>
            </div>
        </div>

        <div class="mb-3">
            <label class="form-label">Materiales</label>
            <input type="text" name="materiales" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Dimensiones</label>
            <input type="text" name="dimensiones" class="form-control" required>
        </div>

        <div class="form-check mb-3">
            <input class="form-check-input" type="checkbox" name="destacado" value="1">
            <label class="form-check-label">Destacado</label>
        </div>

        <div class="mb-3">
            <label class="form-label">Imagen principal</label>
            <input type="file" name="imagen" class="form-control" accept="image/*" required>
        </div>

        <button class="btn btn-primary">Crear mueble</button>
        <a href="{{ route('muebles.index', ['sesionId' => $sesionId]) }}" class="btn btn-secondary">Cancelar</a>
    </form>
@endsection
