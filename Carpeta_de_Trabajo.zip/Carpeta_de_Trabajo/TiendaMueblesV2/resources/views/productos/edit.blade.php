@extends('cabecera')

@section('contenido')

    <h2 class="mb-4">Editar Mueble: {{ $producto->nombre }}</h2>

    {{-- Mensajes --}}
    @if (session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif
    @if (session('error'))
        <div class="alert alert-danger">{{ session('error') }}</div>
    @endif
    @if ($errors->any())
        <div class="alert alert-danger">
            @foreach ($errors->all() as $error)
                <div>{{ $error }}</div>
            @endforeach
        </div>
    @endif

    <form action="{{ route('productos.update', ['producto' => $producto->id]) }}?sesionId={{ $sesionId }}" method="POST">
        @csrf
        @method('PUT')

        {{-- NOMBRE --}}
        <div class="mb-3">
            <label class="form-label">Nombre</label>
            <input type="text" name="nombre" class="form-control" value="{{ $producto->nombre }}" required>
        </div>

        {{-- DESCRIPCIÓN --}}
        <div class="mb-3">
            <label class="form-label">Descripción</label>
            <textarea name="descripcion" class="form-control" rows="3" required>{{ $producto->descripcion }}</textarea>
        </div>

        {{-- PRECIO --}}
        <div class="mb-3">
            <label class="form-label">Precio (€)</label>
            <input type="number" name="precio" class="form-control" step="0.01" value="{{ $producto->precio }}"
                required>
        </div>

        {{-- STOCK --}}
        <div class="mb-3">
            <label class="form-label">Stock</label>
            <input type="number" name="stock" class="form-control" value="{{ $producto->stock }}" required>
        </div>

        {{-- MATERIALES --}}
        <div class="mb-3">
            <label class="form-label">Materiales</label>
            <input type="text" name="materiales" class="form-control" value="{{ $producto->materiales }}">
        </div>

        {{-- DIMENSIONES --}}
        <div class="mb-3">
            <label class="form-label">Dimensiones</label>
            <input type="text" name="dimensiones" class="form-control" value="{{ $producto->dimensiones }}">
        </div>

        {{-- COLOR PRINCIPAL --}}
        <div class="mb-3">
            <label class="form-label">Color principal</label>
            <input type="text" name="color_principal" class="form-control" value="{{ $producto->color_principal }}">
        </div>

        {{-- El valor por defecto cuando NO está marcado --}}
        <input type="hidden" name="destacado" value="0">

        {{-- El checkbox marcado vale 1 --}}
        <input type="checkbox" name="destacado" value="1" {{ $producto->destacado ? 'checked' : '' }}>
        Destacado

        {{-- CATEGORÍA --}}
        <div class="mb-3">
            <label class="form-label">Categoría</label>
            <select name="categoria_id" class="form-select" required>
                <option value="">Seleccione...</option>

                @foreach ($categorias as $cat)
                    <option value="{{ $cat->getId() }}" {{ $producto->categoria_id == $cat->getId() ? 'selected' : '' }}>
                        {{ $cat->getNombre() }}
                    </option>
                @endforeach

            </select>
        </div>

        {{-- ACTUALIZAR --}}
        <button type="submit" class="btn btn-success">Guardar cambios</button>

        <a href="{{ route('muebles.index', ['sesionId' => $sesionId]) }}" class="btn btn-secondary ms-2">
            Cancelar
        </a>
    </form>

    <hr class="my-5">

    {{-- GALERÍA DE IMÁGENES --}}
    <h3>Imágenes del Mueble</h3>

    <div class="row">

        @foreach ($producto->imagenes as $img)
            <div class="col-md-3 text-center mb-4">

                <img src="{{ asset('imagenes/' . $img) }}" class="img-fluid rounded" style="max-height: 150px;">

                <div class="mt-2">

                    {{-- BOTÓN IMAGEN PRINCIPAL --}}
                    <form action="{{ route('productos.galeria.principal', [$producto->id, $img]) }}" method="POST"
                        style="display:inline-block;">
                        @csrf
                        <button class="btn btn-primary btn-sm {{ $producto->imagenes[0] === $img ? 'disabled' : '' }}">
                            Principal
                        </button>
                    </form>

                    {{-- BOTÓN ELIMINAR --}}
                    <form action="{{ route('productos.galeria.destroy', [$producto->id, $img]) }}" method="POST"
                        style="display:inline-block;">
                        @csrf
                        <button class="btn btn-danger btn-sm" onclick="return confirm('¿Eliminar esta imagen?');">
                            Eliminar
                        </button>
                    </form>

                </div>
            </div>
        @endforeach

    </div>

    <hr>

    {{-- SUBIR NUEVAS IMÁGENES --}}
    <h4>Agregar nuevas imágenes</h4>

    <form action="{{ route('productos.galeria.store', $producto->id) }}?sesionId={{ $sesionId }}" method="POST"
        enctype="multipart/form-data">
        @csrf

        <input type="file" name="imagenes[]" multiple accept="image/*" class="form-control mb-3">

        <button class="btn btn-primary">Subir imágenes</button>
    </form>


@endsection
