<?php

namespace Tests\Feature;

use Tests\TestCase;

class AdministracionControllerTest extends TestCase {

}
