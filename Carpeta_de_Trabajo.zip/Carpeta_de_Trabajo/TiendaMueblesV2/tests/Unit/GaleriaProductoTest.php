<?php

namespace Tests\Unit;

use Tests\TestCase;
use Illuminate\Support\Facades\Session;

class GaleriaProductoTest extends TestCase
{

}
