<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('galerias', function (Blueprint $table) {
            $table->id();
            $table->foreignId('producto_id')->constrained('productos')->onDelete('cascade');
            $table->string('ruta'); // Ruta de la imagen
            $table->boolean('es_principal')->default(false); // Imagen principal
            $table->integer('orden')->default(0); // Para reordenar las imágenes
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('galerias');
    }
};
