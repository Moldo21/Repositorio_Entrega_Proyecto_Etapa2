<?php

namespace Database\Seeders;

use App\Models\Carrito;
use App\Models\CarritoItem;
use App\Models\Producto;
use Illuminate\Database\Seeder;

class CarritoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Crear carritos
        $carrito1 = $this->crearCarrito(1, 'sesion_1');
        $carrito2 = $this->crearCarrito(2, 'sesion_2');
    }

    /**
     * Función para crear un carrito y añadirle productos aleatorios respetando el stock
     */
    private function crearCarrito(int $usuarioId, string $sesionId): Carrito
    {
        $carrito = Carrito::create([
            'usuario_id' => $usuarioId,
            'sesionId' => $sesionId,
        ]);

        // Seleccionar 3 productos aleatorios diferentes
        $productos = Producto::inRandomOrder()->take(3)->get();

        foreach ($productos as $producto) {
            // Determinar cantidad aleatoria respetando stock (mínimo 1)
            $maxCantidad = max(1, $producto->stock);
            $cantidad = rand(1, $maxCantidad);

            // Crear registro en carrito_items
            CarritoItem::create([
                'carrito_id' => $carrito->id,
                'producto_id' => $producto->id,
                'cantidad' => $cantidad,
                'precio_unitario' => $producto->precio,
            ]);
        }

        return $carrito;
    }
}
