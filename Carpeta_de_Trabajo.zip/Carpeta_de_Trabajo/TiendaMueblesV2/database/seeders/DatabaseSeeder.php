<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Primero roles
        $this->call(RolSeeder::class);

        // Luego usuarios (dependen de roles)
        $this->call(UsuarioSeeder::class);

        // Categorías
        $this->call(CategoriaSeeder::class);

        // Productos (dependen de categorías)
        $this->call(ProductoSeeder::class);

        $this->call(GaleriaSeeder::class);

        // Carritos (dependen de usuarios y productos)
        $this->call(CarritoSeeder::class);
    }
}
