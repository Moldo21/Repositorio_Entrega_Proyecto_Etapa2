<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\Galeria;
use App\Models\Producto;

class GaleriaFactory extends Factory
{
    protected $model = Galeria::class;

    public function definition()
{
    return [
        'ruta' => $this->faker->imageUrl(640, 480, 'furniture'),
        'es_principal' => false,  // Por defecto secundaria
        'orden' => 1,             // Por defecto orden 1, se puede ajustar en el seeder
    ];
}

// Método para la imagen principal
public function principal()
{
    return $this->state(fn() => ['es_principal' => true, 'orden' => 0]);
}

}
